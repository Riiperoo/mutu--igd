import { GoogleGenAI, Type } from "@google/genai";
import { AppData, AnalysisResult } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const analyzeData = async (data: AppData, query: string): Promise<AnalysisResult> => {
  const model = "gemini-3-flash-preview";

  // Prepare context
  const patientContext = JSON.stringify(data.patients.slice(-50)); 

  const prompt = `
    Anda adalah analis data rumah sakit profesional dan ahli manajemen pelayanan kesehatan.
    
    Berikut adalah data pasien (Monitoring IGD/Rawat Jalan/Inap):
    DATA PASIEN: ${patientContext}
    
    Penjelasan Kolom:
    - Prioritas: P1 (Gawat Darurat), P2 (Urgent), P3 (Semi-Urgent), P4 (Tidak Gawat), P5 (Rutin).
    - DPJP: Dokter Penanggung Jawab Pelayanan.
    - Dokter Spesialis: Keahlian spesifik dokter (Bedah, Anak, dll).
    - Jam Respon: Waktu respon awal perawat/dokter.
    - Masalah: Kendala yang terjadi di lapangan.

    Pertanyaan User: "${query}"
    
    Tugas:
    1. Analisis data untuk menjawab pertanyaan user. Fokus pada efisiensi waktu, beban kerja dokter spesialis, atau distribusi pasien.
    2. Jika perlu visualisasi, buat struktur data grafik.
    3. Jawab dalam Bahasa Indonesia formal medis namun mudah dimengerti.
    
    Format Output (JSON):
    - answer: (String) Penjelasan teks.
    - chartType: (String, optional) 'bar', 'line', atau 'pie'.
    - chartData: (Array, optional) Data grafik.
    - chartTitle: (String, optional) Judul grafik.
    - xAxisKey: (String, optional) Key sumbu X (misal: "name").
    - dataKey: (String, optional) Key nilai (misal: "value").
  `;

  try {
    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            answer: { type: Type.STRING },
            chartType: { type: Type.STRING, enum: ["bar", "line", "pie"] },
            chartTitle: { type: Type.STRING },
            xAxisKey: { type: Type.STRING },
            dataKey: { type: Type.STRING },
            chartData: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING },
                  value: { type: Type.NUMBER },
                },
                required: ["name", "value"]
              }
            }
          },
          required: ["answer"]
        }
      }
    });

    const result = JSON.parse(response.text || "{}");
    return result as AnalysisResult;

  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    return {
      answer: "Maaf, terjadi kesalahan saat menganalisis data medis. Pastikan API Key valid.",
    };
  }
};