import { PatientRecord } from './types';

export const INITIAL_PATIENTS: PatientRecord[] = [];