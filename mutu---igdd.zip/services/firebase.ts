import { initializeApp } from "firebase/app";
import { getAuth, signInAnonymously } from "firebase/auth";
import { 
  getFirestore, 
  collection, 
  getDocs, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  doc,
  query,
  orderBy 
} from "firebase/firestore";
import { PatientRecord } from "../types";

// --- KONFIGURASI FIREBASE ---
const firebaseConfig = {
    apiKey: "AIzaSyBNAUHsZo_fVGStQ9eDeoVtxNHhnyYO3mU",
    authDomain: "mutu-igd.firebaseapp.com",
    projectId: "mutu-igd",
    storageBucket: "mutu-igd.firebasestorage.app",
    messagingSenderId: "1070319434151",
    appId: "1:1070319434151:web:7c183f5554c9b1f4461e82"
};

let db: any;
let auth: any;

try {
    const app = initializeApp(firebaseConfig);
    auth = getAuth(app);
    db = getFirestore(app);

    // LOGIN ANONIM OTOMATIS
    // Kita lakukan login di background.
    // Pastikan Anda sudah mengaktifkan "Anonymous Auth" di Firebase Console -> Build -> Authentication -> Sign-in method.
    signInAnonymously(auth).then(() => {
        console.log("Firebase Auth: Berhasil login anonim.");
    }).catch((error) => {
        console.error("Firebase Auth Error:", error);
    });

} catch (e) {
    console.warn("Firebase Init Error:", e);
}

const COLLECTION_NAME = "patients";

// --- FUNGSI-FUNGSI DATABASE (SERVICE) ---

export const getPatientsFromDB = async (): Promise<PatientRecord[]> => {
  if (!db) return [];
  try {
    const q = query(collection(db, COLLECTION_NAME), orderBy("tanggal", "desc"));
    const querySnapshot = await getDocs(q);
    
    return querySnapshot.docs.map(doc => ({
      ...doc.data(),
      id: doc.id
    })) as PatientRecord[];
  } catch (error) {
    console.error("Error getting documents: ", error);
    throw error;
  }
};

export const addPatientToDB = async (patient: PatientRecord) => {
  if (!db) return;
  try {
    const { id, ...patientData } = patient;
    const docRef = await addDoc(collection(db, COLLECTION_NAME), {
        ...patientData,
        createdAt: new Date()
    });
    return docRef.id;
  } catch (error) {
    console.error("Error adding document: ", error);
    throw error;
  }
};

export const updatePatientInDB = async (patient: PatientRecord) => {
  if (!db) return;
  try {
    const patientRef = doc(db, COLLECTION_NAME, patient.id);
    const { id, ...updateData } = patient;
    await updateDoc(patientRef, updateData);
  } catch (error) {
    console.error("Error updating document: ", error);
    throw error;
  }
};

export const deletePatientFromDB = async (id: string) => {
  if (!db) return;
  try {
    await deleteDoc(doc(db, COLLECTION_NAME, id));
  } catch (error) {
    console.error("Error deleting document: ", error);
    throw error;
  }
};
