import { PatientRecord } from "../types";

// --- KONFIGURASI PERMANEN ---
// Masukkan URL Google Apps Script Anda di sini agar tidak perlu input ulang saat refresh.
// Contoh: "https://script.google.com/macros/s/AKfycbx.../exec"
export const DEFAULT_SHEET_URL: string = "https://script.google.com/macros/s/AKfycbwHdCDWSUatyCHqqZWh1oi9IuDkZc4f-Dc_E3Ryye7pVokP47smouhzeorcKYZTeF1jSw/exec"; 

// Keys for Local Storage
const LS_KEY_URL = 'GOOGLE_SHEET_URL';
const LS_KEY_DATA = 'LOCAL_PATIENTS_DATA';

// Helper to get URL dynamically
const getSheetUrl = () => {
    // 1. Cek LocalStorage (Prioritas utama jika user mengubahnya di menu Setting)
    const localUrl = localStorage.getItem(LS_KEY_URL);
    if (localUrl) return localUrl.trim();

    // 2. Cek Hardcoded URL (Fallback jika LocalStorage kosong)
    const defaultUrl = DEFAULT_SHEET_URL as string;
    if (defaultUrl) return defaultUrl.trim();

    return "";
};

// Helper to simulate network delay for local experience
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// --- HELPER: TIME SANITIZER ---
const sanitizeTime = (val: any): string => {
    if (!val) return "";
    const str = String(val);

    // Case 1: Full ISO String (e.g., "1899-12-30T14:30:00.000Z")
    if (str.includes('T')) {
        try {
            const date = new Date(str);
            const hours = String(date.getHours()).padStart(2, '0');
            const minutes = String(date.getMinutes()).padStart(2, '0');
            return `${hours}:${minutes}`;
        } catch (e) {
            return "";
        }
    }

    // Case 2: Time with seconds (e.g., "14:30:00") -> Cut to "14:30"
    if (str.includes(':') && str.length > 5) {
        return str.substring(0, 5);
    }

    // Case 3: Clean "14:30" or empty
    return str;
};

// --- HELPER: DATE SANITIZER (NEW) ---
// Ensures format is always YYYY-MM-DD for HTML Date Inputs
const sanitizeDate = (val: any): string => {
    if (!val) return "";
    const str = String(val).trim();

    // 1. If it's already YYYY-MM-DD, return it.
    if (/^\d{4}-\d{2}-\d{2}$/.test(str)) return str;

    // 2. Handle ISO String (2024-12-31T...) or Full Date Text
    // Use local time components to avoid timezone shifting the date back by 1 day
    if (str.includes('T') || str.includes('Mon') || str.includes('Tue') || str.includes('Wed')) {
        try {
            const d = new Date(str);
            if (isNaN(d.getTime())) return str; // Invalid date

            const year = d.getFullYear();
            const month = String(d.getMonth() + 1).padStart(2, '0');
            const day = String(d.getDate()).padStart(2, '0');
            return `${year}-${month}-${day}`;
        } catch { return str; }
    }

    // 3. Handle DD/MM/YYYY (Common in Indonesian Google Sheets)
    // Example: 31/12/2024
    if (str.includes('/')) {
        const parts = str.split('/');
        if (parts.length === 3) {
            // Check if part[2] is Year (4 digits) -> DD/MM/YYYY
            if (parts[2].length === 4) {
                 return `${parts[2]}-${parts[1].padStart(2, '0')}-${parts[0].padStart(2, '0')}`;
            }
            // Check if part[0] is Year -> YYYY/MM/DD
            if (parts[0].length === 4) {
                return `${parts[0]}-${parts[1].padStart(2, '0')}-${parts[2].padStart(2, '0')}`;
            }
        }
    }

    return str;
};

const callSheetAPI = async (action: string, payload: any = {}) => {
  const SHEET_API_URL = getSheetUrl();

  // --- MODE 1: LOCAL STORAGE (OFFLINE / NO URL) ---
  if (!SHEET_API_URL) {
    console.log(`[Service] Mode Local Storage: Executing ${action}`);
    await delay(300); // Simulate processing time
    
    let localData: PatientRecord[] = JSON.parse(localStorage.getItem(LS_KEY_DATA) || "[]");

    try {
        switch (action) {
            case 'read':
                return localData;
            
            case 'create':
                localData.unshift(payload); // Add to top
                localStorage.setItem(LS_KEY_DATA, JSON.stringify(localData));
                return payload.id; // Return the ID
            
            case 'update':
                localData = localData.map(p => p.id === payload.id ? payload : p);
                localStorage.setItem(LS_KEY_DATA, JSON.stringify(localData));
                return "success";
            
            case 'delete':
                localData = localData.filter(p => p.id !== payload);
                localStorage.setItem(LS_KEY_DATA, JSON.stringify(localData));
                return "success";
                
            default:
                return [];
        }
    } catch (e) {
        console.error("Local Storage Error", e);
        throw new Error("Gagal menyimpan ke penyimpanan lokal.");
    }
  }

  // --- MODE 2: GOOGLE SHEETS (ONLINE) ---
  const params = new URLSearchParams();
  params.append('action', action);
  
  if (action === 'create' || action === 'update') {
      params.append('data', JSON.stringify(payload));
  } else if (action === 'delete') {
      params.append('id', payload);
  }

  try {
      const response = await fetch(SHEET_API_URL, {
          method: "POST", 
          body: params
      });

      if (!response.ok) {
          throw new Error(`HTTP Error: ${response.status}`);
      }

      const result = await response.json();
      
      if (result.result === 'error') {
          throw new Error(result.error || "Script error");
      }

      return result;

  } catch (error) {
      console.error("Sheet API Error:", error);
      throw new Error("Gagal sinkronisasi dengan Google Sheet. Periksa koneksi internet atau URL Script Anda.");
  }
};

// --- EXPORTED SERVICE FUNCTIONS ---

export const getPatientsFromDB = async (): Promise<PatientRecord[]> => {
  try {
    const rawData = await callSheetAPI("read");
    
    if (Array.isArray(rawData)) {
        // Sanitize data before returning to app
        const cleanData = rawData.map((item: any) => ({
            ...item,
            // Apply sanitizers
            tanggal: sanitizeDate(item.tanggal), // NEW: Fix Date format
            jamDatang: sanitizeTime(item.jamDatang),
            jamRespon: sanitizeTime(item.jamRespon),
            jamDokter: sanitizeTime(item.jamDokter),
            jamKonsul: sanitizeTime(item.jamKonsul),
            jamResponSpesialis: sanitizeTime(item.jamResponSpesialis)
        }));

        return cleanData.sort((a: any, b: any) => {
             const dateA = new Date(a.tanggal).getTime();
             const dateB = new Date(b.tanggal).getTime();
             return dateB - dateA;
        }) as PatientRecord[];
    }
    return [];
  } catch (error) {
    console.error("Get Error:", error);
    throw error;
  }
};

export const addPatientToDB = async (patient: PatientRecord) => {
  try {
    const newId = patient.id || Math.random().toString(36).substr(2, 9);
    const patientWithId = { 
        ...patient, 
        id: newId,
        createdAt: new Date().toISOString()
    };
    
    await callSheetAPI("create", patientWithId);
    return newId;
  } catch (error) {
    console.error("Add Error:", error);
    throw error;
  }
};

export const updatePatientInDB = async (patient: PatientRecord) => {
  try {
    await callSheetAPI("update", patient);
  } catch (error) {
    console.error("Update Error:", error);
    throw error;
  }
};

export const deletePatientFromDB = async (id: string) => {
  try {
    await callSheetAPI("delete", id);
  } catch (error) {
    console.error("Delete Error:", error);
    throw error;
  }
};